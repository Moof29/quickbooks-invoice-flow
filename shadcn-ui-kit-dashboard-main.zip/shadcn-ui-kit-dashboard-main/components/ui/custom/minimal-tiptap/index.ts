export * from './minimal-tiptap'
